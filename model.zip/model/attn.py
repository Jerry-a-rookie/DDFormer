import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
from math import sqrt
import os
from einops import rearrange, reduce, repeat

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class DAC_structure(nn.Module):
    def __init__(self, win_size, patch_size, channel, mask_flag=True, scale=None,
                 attention_dropout=0.05, output_attention=False):
        super(DAC_structure, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)
        self.window_size = win_size
        self.patch_size = patch_size
        self.channel = channel

    def upscale_attn(self, attn, target_size):
        """高效双线性插值上采样注意力图"""
        # 输入形状: [B*C, H, S, S]
        BxC, H, S, _ = attn.shape

        # 重塑为4D张量: [B*C*H, 1, S, S] (添加通道维度)
        attn = attn.view(-1, 1, S, S)

        # 双线性插值上采样到目标尺寸
        attn_upscaled = F.interpolate(
            attn.float(),
            size=(target_size, target_size),
            mode='bilinear',
            align_corners=False
        ).to(attn.dtype)  # 保持原始数据类型

        # 恢复形状: [B*C, H, L, L]
        attn_upscaled = attn_upscaled.view(BxC, H, target_size, target_size)
        return attn_upscaled

    def forward(self, queries_patch_size, queries_patch_num, keys_patch_size,
                keys_patch_num, values, patch_index, attn_mask):
        """
        输入形状:
        queries_patch_size: (B*C, n, H, E)
            [batch*channels, 块数量, 注意力头数, 每个头的维度]
        queries_patch_num: (B*C, p, H, E)
            [batch*channels, 块大小, 注意力头数, 每个头的维度]
        values: (B, L, H, E)
            [batch, 窗口长度, 注意力头数, 每个头的维度]
        """

        # ===== 1. 块间注意力 (Patch-wise) =====
        # 输入形状: (B*C, n, H, E)
        B, L, H, E = queries_patch_size.shape
        scale_patch_size = self.scale or 1. / sqrt(E)

        # 计算注意力分数: (B*C, H, n, n)
        scores_patch_size = torch.einsum("blhe,bshe->bhls",
                                         queries_patch_size,
                                         keys_patch_size)
        # 缩放和softmax: (B*C, H, n, n)
        attn_patch_size = scale_patch_size * scores_patch_size
        series_patch_size = self.dropout(torch.softmax(attn_patch_size, dim=-1))

        # ===== 2. 块内注意力 (In-patch) =====
        # 输入形状: (B*C, p, H, E)
        B, L, H, E = queries_patch_num.shape
        scale_patch_num = self.scale or 1. / sqrt(E)

        # 计算注意力分数: (B*C, H, p, p)
        scores_patch_num = torch.einsum("blhe,bshe->bhls",
                                        queries_patch_num,
                                        keys_patch_num)
        # 缩放和softmax: (B*C, H, p, p)
        attn_patch_num = scale_patch_num * scores_patch_num
        series_patch_num = self.dropout(torch.softmax(attn_patch_num, dim=-1))

        # ===== 3. 高效上采样操作 =====
        # 使用双线性插值替代原始重复操作
        series_patch_size = self.upscale_attn(series_patch_size, self.window_size)
        series_patch_num = self.upscale_attn(series_patch_num, self.window_size)

        # ===== 4. 通道合并 =====
        # 合并通道维度: (B*C, H, L, L) -> (B, H, L, L)
        series_patch_size = reduce(
            series_patch_size,
            '(b reduce_b) h m n-> b h m n',
            'mean',
            reduce_b=self.channel
        )
        series_patch_num = reduce(
            series_patch_num,
            '(b reduce_b) h m n-> b h m n',
            'mean',
            reduce_b=self.channel
        )

        # 返回形状: (B, H, L, L) 和 (B, H, L, L)
        if self.output_attention:
            return series_patch_size, series_patch_num
        else:
            return None


class AttentionLayer(nn.Module):
    def __init__(self, attention, d_model, patch_size, channel, n_heads, win_size,
                 d_keys=None, d_values=None):
        super(AttentionLayer, self).__init__()
        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.norm = nn.LayerNorm(d_model)
        self.inner_attention = attention
        self.patch_size = patch_size
        self.channel = channel
        self.window_size = win_size
        self.n_heads = n_heads

        # 投影层定义
        self.patch_query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.patch_key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)


    def forward(self, x_patch_size, x_patch_num, x_ori, patch_index, attn_mask):
        """
        输入形状:
        x_ori: (B, L, d_model)           [batch, 窗口长度, 特征维度]
        x_patch_num: (B*C, p, d_model)   [batch*channels, 块大小, 特征维度]
        x_patch_size: (B*C, n, d_model)  [batch*channels, 块数量, 特征维度]
        """

        # ===== 1. Patch-wise分支 (块间关系) =====
        # 输入形状: (B*C, n, d_model)
        B, L, M = x_patch_size.shape
        queries_patch_size = keys_patch_size = x_patch_size

        # 线性投影+头分割: (B*C, n, d_model) -> (B*C, n, n_heads, d_keys)
        queries_patch_size = self.patch_query_projection(queries_patch_size)
        queries_patch_size = queries_patch_size.view(B, L, self.n_heads, -1)

        keys_patch_size = self.patch_key_projection(keys_patch_size)
        keys_patch_size = keys_patch_size.view(B, L, self.n_heads, -1)

        # ===== 2. In-patch分支 (块内关系) =====
        # 输入形状: (B*C, p, d_model)
        B, L, M = x_patch_num.shape
        queries_patch_num = keys_patch_num = x_patch_num

        # 线性投影+头分割: (B*C, p, d_model) -> (B*C, p, n_heads, d_keys)
        queries_patch_num = self.patch_query_projection(queries_patch_num)
        queries_patch_num = queries_patch_num.view(B, L, self.n_heads, -1)

        keys_patch_num = self.patch_key_projection(keys_patch_num)
        keys_patch_num = keys_patch_num.view(B, L, self.n_heads, -1)

        # ===== 3. 值投影 =====
        # 输入形状: (B, L, d_model) -> (B, L, n_heads, d_values)
        B, L, _ = x_ori.shape
        values = self.value_projection(x_ori)
        values = values.view(B, L, self.n_heads, -1)

        # ===== 4. 双注意力计算 =====
        # 输出形状:
        #   series: (B, n_heads, L, L) [块间注意力]
        #   prior: (B, n_heads, L, L)  [块内注意力]
        series, prior = self.inner_attention(
            queries_patch_size, queries_patch_num,
            keys_patch_size, keys_patch_num,
            values, patch_index, attn_mask
        )

        return series, prior