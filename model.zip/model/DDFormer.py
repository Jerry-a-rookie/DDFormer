import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from .attn import DAC_structure, AttentionLayer
from .embed import DataEmbedding, TokenEmbedding
from .RevIN import RevIN
from tkinter import _flatten
from .CME import Model as CIModel



device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class Encoder(nn.Module):
    def __init__(self, attn_layers, norm_layer=None):
        super(Encoder, self).__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.norm = norm_layer

    def forward(self, x_patch_size, x_patch_num, x_ori, patch_index, attn_mask=None):
        series_list = []
        prior_list = []
        for attn_layer in self.attn_layers:
            # Input shapes:
            #   x_patch_size: (B*M, n, d_model)
            #   x_patch_num: (B*M, p, d_model)
            # Output shapes:
            #   series: (B*M, n, d_model)
            #   prior: (B*M, p, d_model)
            series, prior = attn_layer(x_patch_size, x_patch_num, x_ori, patch_index, attn_mask=attn_mask)
            series_list.append(series)
            prior_list.append(prior)
        return series_list, prior_list


class DDFormer(nn.Module):
    def __init__(self, win_size, enc_in, c_out, n_heads=1, d_model=256, e_layers=3, patch_size=[3, 5, 7], channel=55,
                 d_ff=512, dropout=0.0, activation='gelu', output_attention=True):
        super(DDFormer, self).__init__()
        self.output_attention = output_attention
        self.patch_size = patch_size
        self.channel = channel
        self.win_size = win_size

        # Patching List
        self.embedding_patch_size = nn.ModuleList()
        self.embedding_patch_num = nn.ModuleList()
        self.inter_FC2 = nn.ModuleList()
        for i, patchsize in enumerate(self.patch_size):
            # 初始化patch-wise和in-patch嵌入层
            self.embedding_patch_size.append(DataEmbedding(patchsize, d_model, dropout))
            self.embedding_patch_num.append(DataEmbedding(self.win_size // patchsize, d_model, dropout))

        # 原始窗口大小的嵌入层
        self.embedding_window_size = DataEmbedding(enc_in, d_model, dropout)

        # 双注意力编码器 (包含e_layers层)
        self.encoder = Encoder(
            [
                AttentionLayer(
                    DAC_structure(win_size, patch_size, channel, False, attention_dropout=dropout,
                                  output_attention=output_attention),
                    d_model, patch_size, channel, n_heads, win_size) for l in range(e_layers)
            ],
            norm_layer=torch.nn.LayerNorm(d_model)
        )

        self.projection = nn.Linear(d_model, c_out, bias=True)
        self.CIModel=CIModel(win_size=self.win_size,input_c=enc_in,n_heads=2,factor=5,e_layers=1,dropout=0.4,activation="gelu",output_attention = True)

        # self.inter_FC=FCLinear(enc_in,enc_in,win_size)


    def forward(self, x):
        # 输入x形状: (B, L, M) = (batch_size, window_size, num_channels)
        B, L, M = x.shape

        # 初始化列表存储多尺度结果
        series_patch_mean = []
        prior_patch_mean = []

        # 实例化RevIN归一化层
        revin_layer = RevIN(num_features=M)

        # 1. 实例归一化操作
        # 输入: (B, L, M) -> 输出: (B, L, M)
        x = revin_layer(x, 'norm')
        x=self.CIModel(x)

        # 2. 原始窗口嵌入
        # 输入: (B, L, M) -> 输出: (B, L, d_model)
        x_ori = self.embedding_window_size(x)


        # 3. 多尺度分块处理
        for patch_index, patchsize in enumerate(self.patch_size):
            # 复制输入用于两个分支
            x_patch_size, x_patch_num = x, x

            # 3.1 PATCH-WISE分支 (关注块间关系)
            # 重组: (B, L, M) -> (B, M, L)
            x_patch_size = rearrange(x_patch_size, 'b l m -> b m l')
            # 分块操作: (B, M, L) -> (B*M, n, p)
            # n = L // p = 块数量, p = patchsize
            x_patch_size = rearrange(x_patch_size, 'b m (n p) -> (b m) n p', p=patchsize)
            # 嵌入层: (B*M, n, p) -> (B*M, n, d_model)
            x_patch_size = self.inter_FC2[patch_index](x_patch_size)
            x_patch_size = self.embedding_patch_size[patch_index](x_patch_size)



            # 3.2 IN-PATCH分支 (关注块内关系)
            # 重组: (B, L, M) -> (B, M, L)
            x_patch_num = rearrange(x_patch_num, 'b l m -> b m l')
            # 分块操作: (B, M, L) -> (B*M, p, n)
            x_patch_num = rearrange(x_patch_num, 'b m (p n) -> (b m) p n', p=patchsize)
            # 嵌入层: (B*M, p, n) -> (B*M, p, d_model)
            x_patch_num = self.embedding_patch_num[patch_index](x_patch_num)


            # 4. 双注意力编码器处理
            # 输入:
            #   x_patch_size: (B*M, n, d_model)
            #   x_patch_num: (B*M, p, d_model)
            # 输出:
            #   series: 列表[e_layers个(B*M, n, d_model)]
            #   prior: 列表[e_layers个(B*M, p, d_model)]
            series, prior = self.encoder(x_patch_size, x_patch_num, x_ori, patch_index)

            # 存储当前尺度的结果
            series_patch_mean.append(series)
            prior_patch_mean.append(prior)

        # 5. 展平多尺度结果
        # 将列表[尺度1[层1, 层2,...], 尺度2[层1, 层2,...], ...]
        # 展平为[尺度1层1, 尺度1层2, ..., 尺度2层1, ...]
        series_patch_mean = list(_flatten(series_patch_mean))
        prior_patch_mean = list(_flatten(prior_patch_mean))

        # 6. 返回注意力结果
        if self.output_attention:
            return series_patch_mean, prior_patch_mean
        else:
            return None

def test_model_shapes_simple():
    # 设置模型参数
    win_size = 105
    enc_in = 38
    c_out = 1
    patch_size = [5,7]
    d_model = 256
    e_layers = 3
    n_heads = 8
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"测试设备: {device}")
    # 创建模型实例
    model = DDFormer(
        win_size=win_size,
        enc_in=enc_in,
        c_out=c_out,
        n_heads=n_heads,
        d_model=d_model,
        e_layers=e_layers,
        patch_size=patch_size,
        channel=enc_in,
        output_attention=True
    ).to(device)

    # 生成模拟输入数据
    batch_size = 1
    x = torch.randn(batch_size, win_size, enc_in).to(device) #（2，90，55）

    # 打印输入shape
    print(f"输入 shape: {x.shape} (B={batch_size}, L={win_size}, M={enc_in})")

    # 前向传播
    series_output, prior_output = model(x)

    # 打印输出shape
    print("\n输出 shape 信息:")
    print(f"series_output 长度: {len(series_output)}")
    print(f"prior_output 长度: {len(prior_output)}")

    # 打印第一个和最后一个输出的shape
    print(f"\n第一个 series 输出 shape: {series_output[0].shape}")
    print(f"最后一个 series 输出 shape: {series_output[-1].shape}")
    print(f"\n第一个 prior 输出 shape: {prior_output[0].shape}")
    print(f"最后一个 prior 输出 shape: {prior_output[-1].shape}")

    return model, x, series_output, prior_output


# 运行测试
if __name__ == "__main__":
    model, x, series, prior = test_model_shapes_simple()